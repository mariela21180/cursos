import React, { Component } from 'react';


class Header extends Component {

  render() {
    return (
      <div className="App">
        MY HEADER
      </div>
    );
  }
}

export default Header;
