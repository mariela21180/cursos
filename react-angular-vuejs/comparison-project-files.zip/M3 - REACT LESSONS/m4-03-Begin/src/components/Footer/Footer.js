import React from 'react';


const Footer = () => {

    return (
      <div className="App">
        MY FOOTER
      </div>
    );
};

export default Footer;
