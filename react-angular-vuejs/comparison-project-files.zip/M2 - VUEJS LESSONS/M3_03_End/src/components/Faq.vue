<template>
  <div class="faq">
    FAQ
  </div>
</template>

<script>
export default {
  name: 'faq'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="sass" scoped>
@import '../mq'


</style>
