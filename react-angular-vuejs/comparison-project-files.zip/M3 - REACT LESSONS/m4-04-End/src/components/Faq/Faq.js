import React, { Component } from 'react';

class Faq extends Component {
    render() {
        return (
            <div>
                Faq
            </div>
        );
    }
}

export default Faq;